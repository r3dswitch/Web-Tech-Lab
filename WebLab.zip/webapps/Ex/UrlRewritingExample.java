import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class UrlRewritingExample extends HttpServlet {

protected void doGet(HttpServletRequest request,
HttpServletResponse response) throws ServletException, IOException {
response.setContentType("text/html");
java.io.PrintWriter out = response.getWriter();
String contextPath = request.getContextPath();
String encodedUrl = response
.encodeURL(contextPath + "/WelcomePage.jsp");

out.println("<html>");
out.println("<head>");
out.println("<title>URL Rewriter</title>");
out.println("</head>");
out.println("<body><center>");
out.println("<h2>URL rewriting Example</h2>");
out.println("For welcome page - <a href=\"" + encodedUrl
+ "\"> Click Here</a>.");
out.println("</center></body>");
out.println("</html>");
}

}