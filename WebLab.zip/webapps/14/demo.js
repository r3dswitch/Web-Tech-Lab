function check()
{
	document.getElementById("fill").innerHTML = "yes it is working";
	
}